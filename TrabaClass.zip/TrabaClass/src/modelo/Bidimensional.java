/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;
public class Bidimensional {
    public static void main(String[] args) {
        int[][] matriz = new int[4][4];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("Ingrese el elemento en la posición [" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }
        scanner.close();
        int valorMayor = matriz[0][0];
        int valorMenor = matriz[0][0];
        int sumaTotal = 0;

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                int valorActual = matriz[i][j];
                
                if (valorActual > valorMayor) {
                    valorMayor = valorActual;
                }
                if (valorActual < valorMenor) {
                    valorMenor = valorActual;
                }

                sumaTotal += valorActual;
            }
        }    
        double promedio = (double) sumaTotal / (matriz.length * matriz[0].length);

      
        System.out.println("Valor mayor: " + valorMayor);
        System.out.println("Valor menor: " + valorMenor);
        System.out.println("Valor promedio: " + promedio);
    }
}

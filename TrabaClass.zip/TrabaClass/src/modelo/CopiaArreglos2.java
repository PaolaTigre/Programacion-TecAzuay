/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class CopiaArreglos2 {
    public static void main(String[] args) {
        long[] arregloPrincipal = new long[10];
        for (int i = 0; i < arregloPrincipal.length; i++) {
            arregloPrincipal[i] = i *10; 
        }
        long[] arregloCopia = new long[arregloPrincipal.length];
        for (int i = 0; i < arregloPrincipal.length; i++) {
            arregloCopia[i] = arregloPrincipal[i];
        }
        System.out.println("Elementos del segundo arreglo:");
        for (int i = 0; i < arregloCopia.length; i++) {
            System.out.println(arregloCopia[i]);
        }
    }
}


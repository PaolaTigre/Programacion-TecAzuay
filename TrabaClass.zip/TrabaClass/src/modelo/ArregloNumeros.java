/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;
public class ArregloNumeros {
    public static void main(String[] args) {
        int[] arreglo = new int[3];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print("Ingrese el valor para la posicion: ");
            arreglo[i] = scanner.nextInt();
        }
        scanner.close();
        System.out.println("Valor del arreglo:");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo [i] );
        }
        System.out.println( );
    }

}




    
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Ejercicio5Frag {
public static void main(String[] args){
double data[] = new double[10];
data[10] = 100;
}
}

//El código proporcionado tiene un problema y
//generará una excepción en tiempo de ejecución
//un arreglo en Java es de 0 hasta tamaño - 1, en este
//caso, de 0 a 9 para un arreglo de tamaño 10. Sin embargo,
//en el código proporcionado, estás intentando asignar un 
//valor al índice 10, que está fuera del rango permitido.


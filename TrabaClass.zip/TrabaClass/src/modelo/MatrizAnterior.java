/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class MatrizAnterior {

    public static void main(String[] args) {
        int[][] matriz = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12},
                {13, 14, 15, 16}
        };
        if (matriz.length % 2 != 0 || matriz[0].length % 2 != 0) {
            System.out.println("La matriz no es de tamaño par. Saliendo del programa.");
            return;
        }
        System.out.println("Elementos en el Cuarto Cuadrante:");
        int filas = matriz.length;
        int columnas = matriz[0].length;

        for (int i = filas / 2; i < filas; i++) {
            for (int j = columnas / 2; j < columnas; j++) {
                System.out.println("Matriz[" + i + "][" + j + "]: " + matriz[i][j]);
            }
        }
    }
}

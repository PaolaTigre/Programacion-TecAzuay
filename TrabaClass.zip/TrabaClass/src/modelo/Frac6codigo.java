/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
public class Frac6codigo {
    double data[ ];
//data[0] = 29.95;
}

//Elcódigo que proporcionas es incorrecto y resultaría en un 
//error al intentar ejecutarlo. En Java, la declaración y creación de un arreglo de tipo double lo correcto seria el siguiente

//double[] data = new double[tamaño];

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.Scanner;

public class ArreglosEnteros {

    public class EliminarElementosApp {

        public static void main(String[] args) {
            ArrayList<Integer> arreglo = new ArrayList<>();

            Scanner scanner = new Scanner(System.in);
            for (int i = 0; i < 10; i++) {
                System.out.print("Ingrese el valor para la posición " + i + ": ");
                arreglo.add(scanner.nextInt());
            }

            arreglo.remove(8);
            arreglo.remove(4);
            arreglo.remove(2);

            System.out.println("Arreglo después de eliminar elementos:");
            for (int i = 0; i < arreglo.size(); i++) {
                System.out.println("Posición " + i + ": " + arreglo.get(i));
            }
            scanner.close();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
 import java.util.Scanner;
public class ArregloChar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el tamaño del arreglo de entre 10 y 20: ");
        int tamano = scanner.nextInt();
        if (tamano < 10 || tamano > 20) {
            System.out.println("Tamaño no válido. Debe estar entre 10 y 20.");
            return;
        }
        char[] arreglo = new char[tamano];
        for (int i = 0; i < tamano; i++) {
            System.out.print("Ingrese el valor para el elemento " + i + ": ");
            arreglo[i] = scanner.next().charAt(0);
        }
        System.out.println("Valores en orden inverso:");

        for (int i = tamano - 1; i >= 0; i--) {
            System.out.print(arreglo[i] + " ");
        }
        scanner.close();
    }
}



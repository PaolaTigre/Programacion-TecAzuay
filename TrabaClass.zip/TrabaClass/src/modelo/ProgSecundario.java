/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;

public class ProgSecundario {

    public static void main(String[] args) {
        int[][] matriz = new int[4][4];
        try (Scanner scanner = new Scanner(System.in)) {
            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    System.out.print("Ingrese el elemento en la posicion [" + i + "][" + j + "]: ");
                    matriz[i][j] = scanner.nextInt();
                }
            }
            int valorMayor = matriz[0][0];
            int valorMenor = matriz[0][0];
            int sumaTotal = 0;

            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    int elemento = matriz[i][j];

                    if (elemento > valorMayor) {
                        valorMayor = elemento;
                    }
                    if (elemento < valorMenor) {
                        valorMenor = elemento;
                    }
                    sumaTotal += elemento;
                }
            }

            double promedio = (double) sumaTotal / (matriz.length * matriz[0].length);
            System.out.println("Valor Mayor: " + valorMayor);
            System.out.println("Valor Menor: " + valorMenor);
            System.out.println("Valor Promedio: " + promedio);
            System.out.println("Elementos de la Diagonal Secundaria:");
            for (int i = 0; i < matriz.length; i++) {
                System.out.println(matriz[i][matriz.length - 1 - i]);
            }
        }
    }
}

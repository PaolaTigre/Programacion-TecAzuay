/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Usuario
 */
import java.util.Scanner;

public class Matrizfilas10 {

    public class SumatoriaFilasColumnas {

        public static void main(String[] args) {

            int[][] matriz = new int[5][5];
            Scanner scanner = new Scanner(System.in);
            for (int i = 0; i < matriz.length; i++) {
                for (int j = 0; j < matriz[i].length; j++) {
                    System.out.print("Ingrese el elemento en la posición [" + i + "][" + j + "]: ");
                    matriz[i][j] = scanner.nextInt();
                }
            }
            System.out.println("\nSumatoria de cada fila:");
            for (int i = 0; i < matriz.length; i++) {
                int sumatoriaFila = 0;
                for (int j = 0; j < matriz[i].length; j++) {
                    sumatoriaFila += matriz[i][j];
                }
                System.out.println("Fila " + i + ": " + sumatoriaFila);
            }
            System.out.println("\nSumatoria de cada columna:");
            for (int j = 0; j < matriz[0].length; j++) {
                int sumatoriaColumna = 0;
                for (int i = 0; i < matriz.length; i++) {
                    sumatoriaColumna += matriz[i][j];
                }
                System.out.println("Columna " + j + ": " + sumatoriaColumna);
            }
            scanner.close();
        }
    }
}
